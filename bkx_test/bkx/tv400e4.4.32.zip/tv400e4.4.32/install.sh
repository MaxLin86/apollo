#!/bin/sh

./scripts/mwcap-install.sh
