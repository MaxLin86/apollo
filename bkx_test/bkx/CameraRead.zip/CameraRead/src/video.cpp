/** 
 * @Author: cash
 * @Date: 2020-11-27 09:24:29
 * @LastEditors: cash
 * @LastEditTime: 2020-11-30 11:08:33
 * @Description: 
 * @FilePath: /tv400e4.4.32/home/bkx/work/task/CameraRead/src/video.cpp
 */
#include "video.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <getopt.h>           
#include <fcntl.h>            
#include <unistd.h>
#include <errno.h>
#include <malloc.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/mman.h>
#include <sys/ioctl.h>


#include <asm/types.h>        
#include <linux/v4l2-mediabus.h>

#define V4L2_CID_I2C_IO							( 0x08000000 )
#define V4L2_CID_I2C_IO_PRINT					( 0x08000001 )
#define V4L2_CID_SIGNAL_STATUS					( 0x08000002 )
#define V4L2_CID_SWAP_HOR						( 0x08000003 )
#define V4L2_CID_SWAP_VER						( 0x08000004 )
#define V4L2_CID_GAIN_R							( 0x08000005 )
#define V4L2_CID_GAIN_G							( 0x08000006 )
#define V4L2_CID_GAIN_B							( 0x08000007 )

#define CAMERA_DEVICE "/dev/video0"


#define CMD_GET   1
#define CMD_SET   2
#define PRINT_HELP_EXIT do {printf("\nUsage: %s \n\tcmd:\n\t[gs](get signal status)\n\t[g|s][i](get|set input channel) index(hex) \n\t[g|s][h|v](get|set  horizontal|vertical mirror) index(hex) ]\n\t[g|s][r|g|b](get|set RGB gain value) index(hex) ]\n\n\tcmd example:si 1 (set input channel:1)\n\n", argv[0]); return -1;} while(0)

#define CMD_SIGNAL_STATUS   	1
#define CMD_INPUT   			2
#define CMD_H_MIRROR   			3
#define CMD_V_MIRROR   			4
#define CMD_R_GAIN   			5
#define CMD_G_GAIN   			6
#define CMD_B_GAIN   			7
video::video(/* args */)
{
}

video::~video()
{
}

bool video::init(){
	fd_ = open(CAMERA_DEVICE, O_RDWR, 0);
	if (fd_ < 0) {
		perror("Open /dev/video failed\n");
		return false;
	}
}


bool video::IsConnect(){ 
	struct v4l2_control con;
    con.id = V4L2_CID_SIGNAL_STATUS; 
    ioctl(fd_, VIDIOC_G_CTRL, &con);
}

bool video::SetInput(int value){ 
    if (-1 == ioctl(fd_, VIDIOC_S_INPUT, &value)) {
        perror("VIDIOC_S_INPUT");
        return false;
    }
    return true;
}


bool video::GetInput(struct v4l2_input &input){
	//获取视频输入源序号
    int value;
    if (-1 == ioctl(fd_, VIDIOC_G_INPUT, &value)){
        perror("VIDIOC_G_INPUT");
        // exit(EXIT_FAILURE);
        return false;
    }
    // printf("Current input sel is :%d\n", value);
    
    //获取视频输入源序号对应的名称
    input.index = value;  //check index 3 's name 
    if (-1 == ioctl(fd_, VIDIOC_ENUMINPUT, &input)) {
        perror("VIDIOC_ENUMINPUT");
        // exit(EXIT_FAILURE);
        return false;
    }
    return true;
}

int video::GetHorizon(){ 
    return GetInfo(V4L2_CID_SWAP_HOR);   
}
 
bool video::SetHorizon(bool flag){
    return SetCmd(V4L2_CID_SWAP_HOR, flag);   
}

int video::GetVertical(){ 
    return GetInfo(V4L2_CID_SWAP_VER);  
}

//设置垂直镜像:  0 : 无镜像     1   垂直镜像
bool video::SetVertical(bool flag){
    return SetCmd(V4L2_CID_SWAP_VER, flag);  
}

//gain_r
bool video::SetGain_r(bool flag){
    return SetCmd(V4L2_CID_GAIN_R, flag); 
}

int video::GetGain_r(){ 
    return GetInfo(V4L2_CID_GAIN_R); 
}

//gain_g
bool video::SetGain_g(bool flag){
    return SetCmd(V4L2_CID_GAIN_G, flag);
}

int video::GetGain_g(){
    return GetInfo(V4L2_CID_GAIN_G);
}

//gain_b
bool video::SetGain_b(bool flag){
    return SetCmd(V4L2_CID_GAIN_B, flag);
}

int video::GetGain_b(){
    return GetInfo(V4L2_CID_GAIN_B);
}

bool video::SetCmd(int id,bool value){ 
	struct v4l2_control con; 
    con.id = id; 
    con.value = value;   
    ioctl(fd_, VIDIOC_S_CTRL, &con);
}

int video::GetInfo(int id){

    int value;
	struct v4l2_control con; 
    con.id = id; 
    if (-1 == ioctl(fd_, VIDIOC_G_CTRL, &con)){
        perror("VIDIOC_G_INPUT");
        // exit(EXIT_FAILURE);
        return -1;
    }
    return con.value;
}