/** 
 * @Author: cash
 * @Date: 2020-11-27 09:17:32
 * @LastEditors: cash
 * @LastEditTime: 2020-11-27 09:17:32
 * @Description: 
 * @FilePath: /tv400e4.4.32/home/bkx/work/task/CameraRead/src/camera_read.h
 */

int camera_read_into(int argc, char **argv);