 
#include "xml/pugixml.hpp"
#include "misc.h"
#include <iostream>
#include "camera_read.h"
#include "video.h"

int main(int argc, char **argv) {
    // printf("\nUsage: %s \n\tcmd:\n\t[gs](get signal status)\n\t[g|s][i](get|set input channel) index(hex) \n\t[g|s][h|v](get|set  horizontal|vertical mirror) index(hex) ]\n\t[g|s][r|g|b](get|set RGB gain value) index(hex) ]\n\n\tcmd example:si 1 (set input channel:1)\n\n", argv[0]);
    // return -1;
    std::vector<std::string> addr;
    int number;
    // if (!GetConfigData(addr,number))
    // {
    //     std::cout << "get addr failed" << std::endl;
    //     return -1;
    // }
    // AHD的摄像头
    // camera_read_into(argc, argv);

    video vd;
    if(!vd.init()){
        print_err("video init faild");
        return -1;
    }
    struct v4l2_input input;
    if (!vd.GetInput(input))
    {
        print_err("GetInput faild");
        return -1;
    }
    return 0;
}
