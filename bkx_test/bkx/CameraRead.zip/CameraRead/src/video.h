/** 
 * @Author: cash
 * @Date: 2020-11-27 09:24:23
 * @LastEditors: cash
 * @LastEditTime: 2020-11-30 11:03:11
 * @Description: 
 * @FilePath: /tv400e4.4.32/home/bkx/work/task/CameraRead/src/video.h
 */

#include <linux/videodev2.h>
class video
{
public:
    video(/* args */);
    ~video();
    bool init();
    bool IsConnect();
    bool SetInput(int value);
    bool GetInput(struct v4l2_input &input);

    //水平镜像
    int GetHorizon(); 
    bool SetHorizon(bool flag);

    //垂直镜像
    int GetVertical();
    bool SetVertical(bool flag); 

    //gain_r
    int GetGain_r();
    bool SetGain_r(bool flag); 
    //gain_g
    int GetGain_g();
    bool SetGain_g(bool flag); 
    //gain_b
    int GetGain_b();
    bool SetGain_b(bool flag); 

private:
    bool SetCmd(int id,bool value);
    int GetInfo(int id);
    int fd_;
    /* data */
};
