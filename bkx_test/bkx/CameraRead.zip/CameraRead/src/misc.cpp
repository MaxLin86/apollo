
#include "xml/pugixml.hpp"
#include "misc.h"
#include <iostream> 

#include <stdexcept> 
bool GetConfigData(std::vector<std::string> &addr,int &number){
    pugi::xml_document doc;  
    std::string cfg_file = "config/config.xml"; 
    if (!doc.load_file(cfg_file.c_str(), pugi::parse_default, pugi::encoding_utf8))
    {
        std::cout << "open cfg file fail:" << cfg_file << std::endl; 
        return false;
    }
    pugi::xml_node net_node = doc.child("CameraRead").child("device"); 
    pugi::xml_node num_node = doc.child("CameraRead").child("number"); 
    try
    {
        number = std::stoi(num_node.attribute("value").value());
        //便利子节点
        for (pugi::xml_node node = net_node.first_child(); node; node = node.next_sibling())
        {
            addr.push_back(node.attribute("ip").value());
            // ip = node.attribute("ip").value();
            // LOGE << ip;
        }

        // ip = net_node.child("addr").attribute("ip").value();
        // port = std::stoi(net_node.child("addr").attribute("port").value()); 
    }
    catch (std::invalid_argument &e)
    { 
        // std::cout << "open cfg file fail:" << cfg_file << std::endl;
        std::cout << "Parse cfg file\"" << cfg_file << "\" fail，invalid_argument: " << e.what() << std::endl;
        // err_msg = "invalid_argument:" +std::string(const_cast<char *>(e.what()));
        return false;
    }
    return true;
}

void print_err(const std::string &err){

    printf("\x1b[;%dm%s\n\x1b[0m", 31, err.c_str()); //红色
    // printf("\x1b[;%dmhello world\n\x1b[0m", 32);     //绿色
}

void print_success(const std::string &err){
    printf("\x1b[;%dm%s\n\x1b[0m", 32, err.c_str()); //绿色
 
}