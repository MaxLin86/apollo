
#include <string>
#include<vector>

bool GetConfigData(std::vector<std::string> &addr,int &number);//读取配置文件数据

void print_err(const std::string &err);//打印报错信息

void print_success(const std::string &err);//打印成功信息