// Copyright (C) Uhnder, Inc. All rights reserved. Confidential and Proprietary - under NDA.
// Refer to SOFTWARE_LICENSE file for details
#ifndef SRS_HDR_TCS_CAL_FLASHDATA_H
#define SRS_HDR_TCS_CAL_FLASHDATA_H 1

#include "modules/drivers/radar/rocket_radar/driver/system-radar-software/env-reference/coredefs/uhnder-common.h"
#include "modules/drivers/radar/rocket_radar/driver/system-radar-software/engine/common/eng-api/rhal_out.h"
#include "modules/drivers/radar/rocket_radar/driver/system-radar-software/engine/scp-src/eng-api/default-presets.h"

SRS_DECLARE_NAMESPACE()


struct CarrSupData
{
    uint8_t             itrim_p_en_hv_i; // tx0_idac_generic : itrim_p_en_hv
    uint8_t             itrim_n_en_hv_i; // tx0_idac_generic : itrim_n_en_hv
    uint8_t             itrim_p_en_hv_q; // tx0_qdac_generic : itrim_p_en_hv
    uint8_t             itrim_n_en_hv_q; // tx0_qdac_generic : itrim_n_en_hv
    int8_t              dc_offset_i;     // dc_offset_tx00 : dc_offset_correct_i
    int8_t              dc_offset_q;     // dc_offset_tx00 : dc_offset_correct_q
};

struct TCSCalData
{
    CarrSupData tx_carrier_sup_data[NUM_TX];

    void uhprint(bool all=false) const
    {
        for (uint32_t i = 0; i < NUM_TX; i++)
        {
            UHPRINTF("TX[%d] itrim P %u %u N %u %u DC %d %d\n", i,
                    tx_carrier_sup_data[i].itrim_p_en_hv_i,
                    tx_carrier_sup_data[i].itrim_p_en_hv_q,
                    tx_carrier_sup_data[i].itrim_n_en_hv_i,
                    tx_carrier_sup_data[i].itrim_n_en_hv_q,
                    tx_carrier_sup_data[i].dc_offset_i,
                    tx_carrier_sup_data[i].dc_offset_q);
            if (!all) break;
        }
    }

    void set_defaults()
    {
        for (uint32_t i = 0; i < NUM_TX; i++)
        {
            tx_carrier_sup_data[i].itrim_p_en_hv_i = 77; // Sabine-B defaults
            tx_carrier_sup_data[i].itrim_p_en_hv_q = 77;
            tx_carrier_sup_data[i].itrim_n_en_hv_i = 77;
            tx_carrier_sup_data[i].itrim_n_en_hv_q = 77;
            tx_carrier_sup_data[i].dc_offset_i = 0;
            tx_carrier_sup_data[i].dc_offset_q = 0;
        }
    }
};


struct TCSKey
{
    FLOAT                     temp;         // Chip temperature C at which this cal was performed
    uint32_t                  reserved_tx_ant_bmap;  // Out of 1 Txs (RevA)
    uint32_t                  reserved_rx_ant_bmap;  // Out of 16 Rxs (RevA)
    RHAL_TxBWPresets          tx_bw_enum;
    RHAL_RxBWPresets          reserved_rx_bw_enum;
    RHAL_RxVGAGainPresets     reserved_rx_vga_gain_enum;
    RHAL_TxGainPresets        tx_gain_enum;
    uint32_t                  reserved_lomode;
    FLOAT                     carrier_freq;

    uint32_t                  reserved_0;
    uint32_t                  reserved_1;
    uint32_t                  reserved_2;
    uint32_t                  reserved_3;
    uint32_t                  reserved_4;
    uint32_t                  reserved_5;
    uint32_t                  reserved_6;

    enum { KEY_VERSION = 1 };

    TCSKey() { memset(this, 0, sizeof(*this)); }

    void upgrade_from_version(uint32_t old_version, TCSCalData&)
    {
        if (old_version < 1)
        {
            carrier_freq = DEF_RF;
        }
    }

    void uhprint() const
    {
        UHPRINTF("(TCS) temp: %f\n", temp);
        UHPRINTF("tx_bw_enum: %d %s\n", tx_bw_enum, tx_bw_names[tx_bw_enum]);
        UHPRINTF("tx_gain_enum: %d %s\n", tx_gain_enum, tx_gain_names[tx_gain_enum]);
        UHPRINTF("carrier_freq: %.2f\n", carrier_freq);
    }

    //!! This is the all-important key-search algorithm !!
    bool compare(const TCSKey& other) const
    {
        return (//uh_fabsf(temp - other.temp) < 1.5F &&
                (uh_fabsf(carrier_freq - other.carrier_freq) <= 0.2F) &&
                tx_bw_enum == other.tx_bw_enum &&
                tx_gain_enum == other.tx_gain_enum);
    }

    // find the 'nearest-match' by picking the key with the shortest disance
    // from the reference key
    FLOAT distance(const TCSKey& other) const
    {
        FLOAT dist = uh_fabsf(temp - other.temp) + uh_fabsf(carrier_freq - other.carrier_freq) * 5;
        INT diffs = !(tx_bw_enum == other.tx_bw_enum);
        diffs += !(tx_gain_enum == other.tx_gain_enum);
        return dist + CAL_KEY_DO_NOT_USE * float(diffs);
    }
};


SRS_CLOSE_NAMESPACE()

#endif // SRS_HDR_TCS_CAL_FLASHDATA_H
