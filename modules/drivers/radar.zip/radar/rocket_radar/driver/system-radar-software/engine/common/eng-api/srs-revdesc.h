// Machine generated file, do not edit
const char* swrev = "hg-tag-string:srs-v0.7.6-Au+0-f4fdc93d3511";
const uint32_t swrev_id[] = { 0xf4fdc93d, 0x3511197b };
const char* timestamp = "2020-11-07 16:21:31.657069";
const char* srs_path = "/home/jenkins/.jenkins/workspace/New-bld-installer/rcc3/radar-remote-api/system-radar-software";
