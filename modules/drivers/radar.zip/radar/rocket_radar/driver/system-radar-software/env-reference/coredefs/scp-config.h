// Copyright (C) Uhnder, Inc. All rights reserved. Confidential and Proprietary - under NDA.
// Refer to SOFTWARE_LICENSE file for details
#ifndef SRS_HDR_SCP_CONFIG_H
#define SRS_HDR_SCP_CONFIG_H 1

#include "sabine-b-config.h"

#endif // ifndef SRS_HDR_SCP_CONFIG_H
