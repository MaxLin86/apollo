#pragma once

// hack to allow us to include internal headers
#define DEVPTR(type) type *
