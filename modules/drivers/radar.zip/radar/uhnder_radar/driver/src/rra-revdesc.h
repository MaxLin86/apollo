#pragma once

// Machine generated file, do not edit
const char* swrev = "hg-tag-string:rra-v0.6.3-BF6+0-9c3f1dc3fdd2";

