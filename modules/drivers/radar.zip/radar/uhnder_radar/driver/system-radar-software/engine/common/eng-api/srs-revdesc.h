
// Machine generated file, do not edit
const char* swrev = "hg-tag-string:srs-v0.6.3-BF6+0-864cc25dd2bc";
const uint32_t swrev_id[] = { 0x864cc25d, 0xd2bc8562 };

