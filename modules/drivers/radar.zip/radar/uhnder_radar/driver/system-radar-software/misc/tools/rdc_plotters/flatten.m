function [ output ] = flatten( input )
%flatten matrix
output = reshape(input,1,[]);
end

