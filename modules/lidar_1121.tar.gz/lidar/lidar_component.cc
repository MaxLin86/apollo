 
#include "modules/lidar/lidar_component.h"

#include "cyber/common/log.h" 
// #include <iostream> 


namespace apollo {
namespace lidar {
  
bool LidarComponent::Init() { 
  //      FLAGS_max_log_size = 1;
  //    FLAGS_colorlogtostderr = true;  // Set log color
  //   //  FLAGS_minloglevel = google::GLOG_WARNING;//记录的最小级别
  //    FLAGS_minloglevel = google::GLOG_ERROR;//记录的最小级别
  // return true;
  if (!GetProtoConfig(&lidar_conf_)) {
    AERROR << "Unable to load lidar conf file: " << ConfigFilePath();
    return false;
  } 
  benewake_ = std::make_shared<benewake>();
  benewake_->init(lidar_conf_.dev_serial_name()); 
  BenewakeLidar_writer_ = node_->CreateWriter<lidar::BenewakeLidar>("apollo/lidar");
  return true;
}

bool LidarComponent::Proc() { 
  // static int num = 0;
  // num++;
  //   LOG_FIRST_N(INFO, 20) << "LOG_FIRST_N:num= " << num;  //当此语句执行的前 20 次都输出日志，然后不再输出
  //   LOG_EVERY_N(INFO, 20) << "LOG_EVERY_N:num= " <<num; 

  //   LOG(ERROR) << "error test";  //输出一个Error日志
  //   // LOG(FATAL) << "FATAL test";  //打印 FATAL 消息会在打印完成后终止程序
  //   LOG(WARNING) << "warning test";  //输出一个Warning日志
  //   LOG(INFO) << "info test" << "hello log!";  //输出一个Info日志
  //   return true;
    lidar::BenewakeLidar benewake_msg;
    if(!benewake_->GetLiarData(benewake_msg)){
      AERROR << "GetLiarData failed";
      return false;
    }

    AERROR << "distance = " << benewake_msg.distance();
    BenewakeLidar_writer_->Write(benewake_msg);  
  return true;
}
 

}  // namespace lidar
}  // namespace apollo
