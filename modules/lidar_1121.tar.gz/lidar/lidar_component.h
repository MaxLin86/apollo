 

#pragma once

#include <memory>

#include "cyber/common/macros.h"
#include "cyber/component/timer_component.h"
#include "cyber/cyber.h"

#include "modules/lidar/benewake.h"

/**
 * @namespace apollo::lidar 
 * @brief apollo::lidar
 */
namespace apollo {
namespace lidar {

class LidarComponent : public apollo::cyber::TimerComponent {
public:
  bool Init() override;
  bool Proc() override;

private: 
  LidarConf lidar_conf_; 
  std::shared_ptr<benewake> benewake_ = nullptr;
  std::shared_ptr<cyber::Writer<lidar::BenewakeLidar>> BenewakeLidar_writer_ =nullptr;
};

CYBER_REGISTER_COMPONENT(LidarComponent)

}  // namespace lidar
}  // namespace apollo
