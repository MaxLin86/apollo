 
#pragma once

#include "gflags/gflags.h"

// data file
DECLARE_string(lidar_conf_file);
