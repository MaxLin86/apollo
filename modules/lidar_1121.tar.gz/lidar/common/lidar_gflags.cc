 
#include "modules/lidar/common/lidar_gflags.h"

// data file
DEFINE_string(lidar_conf_file,
              "/apollo/modules/lidar/conf/lidar_conf.pb.txt",
              "Default lidar conf file");
