#pragma once
#include "cyber/cyber.h"

namespace apollo{
namespace roadguide{

void Util_Hexdump(const uint8_t *pBuf, size_t len);

}  // namespace roadguide
}  // namespace apollo
