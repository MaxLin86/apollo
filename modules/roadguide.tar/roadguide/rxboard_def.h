#pragma once
#include "cyber/cyber.h"

#define RXBOARD_ANTS (2)
